    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_text sf_admin_list_th_name" style="text-align: center">
            <?php echo __('Tiêu đề', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_text sf_admin_list_th_slug" style="text-align: center">
            <?php echo __('Slug', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_boolean sf_admin_list_th_is_active" style="width: 65px" style="text-align: center">
            <?php echo __('Trạng thái', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_date sf_admin_list_th_created_at" style="text-align: center">
            <?php echo __('Ngày tạo', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_foreignkey sf_admin_list_th_created_by" style="text-align: center">
            <?php echo __('Người tạo', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>