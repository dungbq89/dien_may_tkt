<?php

/**
 * ManageParameter actions.
 *
 * @package    Web_Portals
 * @subpackage ManageParameter
 * @author     ngoctv1
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class ManageParameterComponents extends sfComponents
{
}