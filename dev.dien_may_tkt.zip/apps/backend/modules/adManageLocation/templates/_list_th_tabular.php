    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_text sf_admin_list_th_name" style="text-align: center">
            <?php echo __('Tên vị trí', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_text sf_admin_list_th_page" style="text-align: center">
            <?php echo __('Trang hiển thị', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_text sf_admin_list_th_template" style="text-align: center">
            <?php echo __('Mẫu hiển thị', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_text sf_admin_list_th_priority" style="text-align: center">
            <?php echo __('Thứ tự hiển thị', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>