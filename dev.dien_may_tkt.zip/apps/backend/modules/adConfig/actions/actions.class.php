<?php

require_once dirname(__FILE__).'/../lib/adConfigGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/adConfigGeneratorHelper.class.php';

/**
 * adConfig actions.
 *
 * @package    symfony
 * @subpackage adConfig
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class adConfigActions extends autoAdConfigActions
{
}
