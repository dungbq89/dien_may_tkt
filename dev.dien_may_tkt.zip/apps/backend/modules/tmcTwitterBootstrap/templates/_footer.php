<?php $footer = sfConfig::get('app_tmcTwitterBootstrapPlugin_footer', array('copyright' => 'dungbq89@gmail.com')); ?>
<div class="container-fluid" id="footer">
    <p><?php echo __($footer['copyright'], null, 'tmcTwitterBootstrapPlugin') ?></p>
</div>