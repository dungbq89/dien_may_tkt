<?php

require_once dirname(__FILE__).'/../lib/adDocumentCategoryGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/adDocumentCategoryGeneratorHelper.class.php';

/**
 * adDocumentCategory actions.
 *
 * @package    Vt_Portals
 * @subpackage adDocumentCategory
 * @author     ngoctv1
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class adDocumentCategoryActions extends autoAdDocumentCategoryActions
{
}
