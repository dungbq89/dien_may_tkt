<?php

/**
 * VtpProductsCategory filter form.
 *
 * @package    Vt_Portals
 * @subpackage filter
 * @author     ngoctv1
 * @version    SVN: $Id: sfDoctrineFormFilterTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class VtpProductsCategoryFilterAdmin extends BaseVtpProductsCategoryFormFilter
{
  public function configure()
  {
  }
}
