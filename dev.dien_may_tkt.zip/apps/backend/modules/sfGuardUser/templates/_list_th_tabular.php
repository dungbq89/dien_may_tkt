    <?php slot('sf_admin.current_header') ?>
        <th  width="3%" class="sf_admin_text sf_admin_list_th_order_no" style="text-align: center">
            <?php echo __('Order No.', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>

    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
    <th  class="sf_admin_text sf_admin_list_th_email_address" style="text-align: center">
        <?php echo __('Họ đệm', array(), 'messages') ?>
    </th>
    <?php end_slot(); ?>

    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
    <th  class="sf_admin_text sf_admin_list_th_username" style="text-align: center">
        <?php echo __('Tên', array(), 'messages') ?>
    </th>
    <?php end_slot(); ?>

    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_text sf_admin_list_th_username" style="text-align: center">
            <?php echo __('Tên đăng nhập', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_text sf_admin_list_th_email_address" style="text-align: center">
            <?php echo __('Địa chỉ Email', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
    <th  class="sf_admin_text sf_admin_list_th_email_address" style="text-align: center">
        <?php echo __('Điện thoại', array(), 'messages') ?>
    </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_boolean sf_admin_list_th_is_active" style="width: 65px" style="text-align: center">
            <?php echo __('Kích hoạt', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_date sf_admin_list_th_last_login" style="text-align: center">
            <?php echo __('Đăng nhập lần cuối', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_date sf_admin_list_th_created_at" style="text-align: center">
            <?php echo __('Ngày tạo', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>