<?php

/**
 * adManagePersonal module configuration.
 *
 * @package    Vt_Portals
 * @subpackage adManagePersonal
 * @author     ngoctv1
 * @version    SVN: $Id: configuration.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class adManagePersonalGeneratorConfiguration extends BaseAdManagePersonalGeneratorConfiguration
{
}
