<?php

/**
 * adManageAdvertise module configuration.
 *
 * @package    Vt_Portals
 * @subpackage adManageAdvertise
 * @author     ngoctv1
 * @version    SVN: $Id: configuration.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class adManageAdvertiseGeneratorConfiguration extends BaseAdManageAdvertiseGeneratorConfiguration
{
}
