<?php
/**
 * Created by JetBrains PhpStorm.
 * User: ngoctv1
 * Date: 12/11/13
 * Time: 12:44 AM
 * To change this template use File | Settings | File Templates.
 */
class adManageAdvertisesFiltersAdmin extends BaseAdAdvertiseFormFilter
{

}
