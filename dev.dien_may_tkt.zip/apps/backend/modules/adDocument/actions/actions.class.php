<?php

require_once dirname(__FILE__).'/../lib/adDocumentGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/adDocumentGeneratorHelper.class.php';

/**
 * adDocument actions.
 *
 * @package    Vt_Portals
 * @subpackage adDocument
 * @author     ngoctv1
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class adDocumentActions extends autoAdDocumentActions
{
}
