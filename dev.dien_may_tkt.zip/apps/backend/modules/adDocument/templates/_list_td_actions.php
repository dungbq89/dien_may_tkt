<td nowrap="nowrap">
    <div class="btn-group">
        <?php echo $helper->linkToEdit($ad_document, array('params' => array(), 'class_suffix' => 'edit', 'label' => 'Edit',)) ?>
        <?php echo $helper->linkToDelete($ad_document, array('params' => array(), 'confirm' => 'Are you sure?', 'class_suffix' => 'delete', 'label' => 'Delete',)) ?>                </div>
</td>