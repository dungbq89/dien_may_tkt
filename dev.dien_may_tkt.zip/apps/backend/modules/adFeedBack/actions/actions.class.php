<?php

require_once dirname(__FILE__).'/../lib/adFeedBackGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/adFeedBackGeneratorHelper.class.php';

/**
 * adFeedBack actions.
 *
 * @package    symfony
 * @subpackage adFeedBack
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class adFeedBackActions extends autoAdFeedBackActions
{
}
