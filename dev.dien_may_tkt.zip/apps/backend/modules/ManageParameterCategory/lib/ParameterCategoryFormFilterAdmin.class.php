<?php

/**
 * ParameterCategory filter form.
 *
 * @package    Web_Portals
 * @subpackage filter
 * @author     ngoctv1
 * @version    SVN: $Id: sfDoctrineFormFilterTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class ParameterCategoryFormFilterAdmin extends BaseParameterCategoryFormFilter
{
  public function configure()
  {
  }
}
