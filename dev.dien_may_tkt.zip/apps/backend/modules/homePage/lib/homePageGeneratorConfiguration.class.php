<?php

class homePageGeneratorConfiguration extends BasehomePageGeneratorConfiguration
{
}