<?php

class homePageGeneratorHelper extends BasehomePageGeneratorHelper
{
}
