<?php

/**
 * HqBrand actions.
 *
 * @package    symfony
 * @subpackage HqBrand
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class HqBrandComponents extends sfComponents
{
}