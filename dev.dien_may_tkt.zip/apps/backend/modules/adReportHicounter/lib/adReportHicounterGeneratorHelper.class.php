<?php

/**
 * adReportHicounter module helper.
 *
 * @package    Vt_Portals
 * @subpackage adReportHicounter
 * @author     ngoctv1
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class adReportHicounterGeneratorHelper extends BaseAdReportHicounterGeneratorHelper
{
}
