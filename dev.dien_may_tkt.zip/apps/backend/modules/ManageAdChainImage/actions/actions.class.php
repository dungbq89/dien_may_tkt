<?php

require_once dirname(__FILE__).'/../lib/ManageAdChainImageGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/ManageAdChainImageGeneratorHelper.class.php';

/**
 * ManageAdChainImage actions.
 *
 * @package    Web_Portals
 * @subpackage ManageAdChainImage
 * @author     ngoctv1
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class ManageAdChainImageActions extends autoManageAdChainImageActions
{
}
