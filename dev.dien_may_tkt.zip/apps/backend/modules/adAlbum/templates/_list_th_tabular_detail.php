    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_text sf_admin_list_th_name" style="text-align: center">
            <?php echo __('Tên ảnh', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_text sf_admin_list_th_file_path" style="text-align: center">
            <?php echo __('Ảnh minh họa', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_foreignkey sf_admin_list_th_album_id" style="text-align: center">
            <?php echo __('Album', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_text sf_admin_list_th_priority" style="text-align: center">
            <?php echo __('Thứ tự hiển thị', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>    <?php slot('sf_admin.current_header') ?>
        <th  class="sf_admin_boolean sf_admin_list_th_is_active" style="width: 65px" style="text-align: center">
            <?php echo __('Trạng thái', array(), 'messages') ?>
        </th>
    <?php end_slot(); ?>
    <?php include_slot('sf_admin.current_header') ?>