<td nowrap="nowrap">
    <div class="btn-group">
    <?php echo $helper->linkToDelete($ad_photo, array(  'params' =>   array(  ),  'confirm' => 'Are you sure?',  'class_suffix' => 'delete',  'label' => 'Delete',)) ?>                </div>
</td>