<td>
  <input type="checkbox" name="ids[]" value="<?php echo $ad_photo->getPrimaryKey() ?>" class="sf_admin_batch_checkbox" />
</td>
