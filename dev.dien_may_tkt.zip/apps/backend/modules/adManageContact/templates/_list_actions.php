<div class="btn-group">
    <?php echo $helper->linkToNew(array('params' => array(), 'class_suffix' => 'new', 'label' => 'Thêm mới',)) ?>
</div>