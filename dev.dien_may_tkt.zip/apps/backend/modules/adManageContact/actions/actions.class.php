<?php

require_once dirname(__FILE__).'/../lib/adManageContactGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/adManageContactGeneratorHelper.class.php';

/**
 * adManageContact actions.
 *
 * @package    Vt_Portals
 * @subpackage adManageContact
 * @author     ngoctv1
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class adManageContactActions extends autoAdManageContactActions
{


}
