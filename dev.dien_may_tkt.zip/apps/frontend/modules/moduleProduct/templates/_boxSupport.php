
<div class="clear">
</div>
<div class="block block-product-filters">
    <div class="title">
        <span>Hỗ trợ trực tuyến</span>
    </div>
    <div class="listbox">
        <div class="topic-html-content">
            <div class="topic-html-content-body">
                <p><span style="font-size: 8pt;"><a alt="" width="12px" height="12px" border="0"/>&nbsp;Mr. Thao: 0945.327.888</a></span>
                </p>

                <p><span style="font-size: 8pt;"><a alt="" width="12px" height="12px" border="0"/>&nbsp;Hotline: 04 22.11.66.55</a></span>
                </p>

                <p>&nbsp;</p>
            </div>
        </div>

    </div>
</div>
<div class="clear"></div>