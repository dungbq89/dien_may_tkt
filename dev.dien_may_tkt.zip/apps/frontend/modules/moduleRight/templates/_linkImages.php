<div class="link-images">
    <a href="#" class="img-list"><img src="../img/thudientu.jpg" width="300px"></a>
    <a href="#" class="img-list"><img src="../img/tuvanhuongnghiep.jpg" width="300px"></a>
    <a href="#" class="img-list"><img src="../img/chonnghe.jpg" width="300px"></a>
    <a href="#" class="img-list"><img src="../img/tritue.jpg" width="300px"></a>
    <a href="#" class="img-list"><img src="../img/thongbao.jpg" width="300px"></a>
</div>