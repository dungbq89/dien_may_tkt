<div>
    <div>
        <div class="page product-details-page">
            <div class="page-body">
                <div style="text-align: center; margin-bottom: 50px;">
                    <img src="/images/404.jpg" width="400"/>
                </div>

            </div>
        </div>
    </div>

</div>


