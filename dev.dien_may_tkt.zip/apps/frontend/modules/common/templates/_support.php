<div class="left_pico fl">
    <div class="loctim2">
        <h2><a href="/tu-van.html" title="Tư vấn">Tư vấn</a></h2>

        <div class="box_bottom">
            <ul class="list-tin-doc-nhieu">

                <li>

                    <p class="nhanvien">Support:<span> <a href="#">Liên hệ</a></span></p>

                    <p class="nhanvien"></p>

<!--                    <p class="nhanvien">Mr Lợi :<span> <a href="tel:01297504186">01297.504.186</a></span></p>-->
                </li>

            </ul>
        </div>
    </div>
</div>