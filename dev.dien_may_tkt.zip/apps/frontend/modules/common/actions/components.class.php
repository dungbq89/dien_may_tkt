<?php

/**
 * Created by JetBrains PhpStorm.
 * User: ngoctv1
 * Date: 5/6/14
 * Time: 6:08 PM
 * To change this template use File | Settings | File Templates.
 */
class commonComponents extends sfComponents
{

    public function executePagging($request) {

    }

    public function executeSupport($request) {

    }


}
