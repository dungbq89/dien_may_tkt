<?php

class myUser extends sfGuardSecurityUser
{
//    public function getCulture()
//    {
//        sfContext::getInstance()->getUser()->getAttribute('lang');
//    }
//
//    public function setCulture($val)
//    {
//        sfContext::getInstance()->getUser()->setAttribute('lang', $val);
//    }
}
